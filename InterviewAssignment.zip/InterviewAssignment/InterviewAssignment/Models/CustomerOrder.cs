﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterviewAssignment.Models
{

    public class CustomerOrder
    {
        private int OrderId;
        private DateTime OrderDate;
        private String Description;
        private decimal Total;
        public CustomerOrder()
        {
            this.OrderId = -1;
            this.OrderDate = new DateTime();
            this.Description = "Default Description";
            this.Total = new decimal(0.0);
        }
        public CustomerOrder(int OrderId, DateTime OrderDate, String Description, decimal Total)
        {
            this.OrderId = OrderId;
            this.OrderDate = OrderDate;
            this.Description = Description;
            this.Total = Total;
        }


        public int orderId
        {
            get { return this.OrderId; }
        }
        public DateTime orderDate
        {
            get { return this.OrderDate;  }
        }
        public String description
        {
            get { return this.Description; }
        }
        public decimal total
        {
            get { return this.Total; }
        }
    }
}
