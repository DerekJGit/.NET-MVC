﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterviewAssignment.Models
{
    public class CustomerViewModel
    {
        public int CustomerNumber;
        private String FirstName;
        private String LastName;
        public List<CustomerOrder> Orders = new List<CustomerOrder>();


        public CustomerViewModel()
        {
            this.CustomerNumber = 111111;
            this.FirstName = "John";
            this.LastName = "Smith";
        }
        public CustomerViewModel(int CustomerNumber, String FirstName, String LastName)
        {
            this.CustomerNumber = CustomerNumber;
            this.FirstName = FirstName;
            this.LastName = LastName;
        }

        public String FullName
        {
            get { return this.FirstName + " " + this.LastName; }
        }
        

    }
}
