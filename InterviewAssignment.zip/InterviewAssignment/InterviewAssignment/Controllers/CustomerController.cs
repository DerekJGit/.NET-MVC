﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace InterviewAssignment.Controllers
{
    public class CustomerController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Orders()
        {
            Models.CustomerViewModel Model = new Models.CustomerViewModel(111111, "Derek", "James");
            Model.Orders.Add(new Models.CustomerOrder(1, DateTime.Today, "Part 1", (decimal)10.00));
            Model.Orders.Add(new Models.CustomerOrder(2, DateTime.Today, "Part 2", (decimal)20.00));
            Model.Orders.Add(new Models.CustomerOrder(3, DateTime.Today, "Part 3", (decimal)30.00));
            return View(Model);
        }
    }
}